package main;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import javafx.scene.control.*;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Controller{
    ObservableList list = FXCollections.observableArrayList();
    ObservableList superList = FXCollections.observableArrayList();



    private static  List<SuperHero> superHeroList;

    //    public static FightResult (ArrayList<SuperHero> listA, ArrayList<SuperHero> listB){
//        //Implement method body with for loop later
//
//
//        return new FightResult();
//    }

    // Constant representing that there is no way to win the election with the given number of votes.
    public static final int kNotPossible = 1000000000;
    @FXML
    private ComboBox race;

    @FXML
    private ComboBox raceTh;

    @FXML
    private ComboBox strength;


    @FXML
    private TextField stockMin;

    @FXML
    private TextField stockMax;

    @FXML
    private TextField stockAverage;

    @FXML
    private TextField storeMutant;

    @FXML
    private TextField storeHuman;


    @FXML
    private TextArea stockArea;

    @FXML
    private TextField storeSearch;

    @FXML
    private TextField winner;

    @FXML
    private TextField loser;

    @FXML
    private TextField win1;

    @FXML
    private TextField win2;

    @FXML
    private TextField loss1;

    @FXML
    private TextField loss2;

    @FXML
    private TextField ratio1;

    @FXML
    private TextField ratio2;

    private SuperHero superHero;

    /**
     * The constructor.
     * The constructor is called before the initialize() method.
     */
    public Controller() {

    }



    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        LoadData();
        // Initialize the person table with the two columns.

    }

    @FXML private void searchText(ActionEvent event) {
        System.out.println(stockArea.getText());

        String[] str = stockArea.getText().split("\n");
        String text = getListThatContainsString(str,storeSearch.getText());
        stockArea.setText(text);
    }

    @FXML private void battles(ActionEvent event) {
        System.out.println(storeMutant.getText());
        System.out.println(storeHuman.getText());
        DecimalFormat df = new DecimalFormat("0.00");
        if(superHeroList!=null&& !storeMutant.getText().equals("") && !storeHuman.getText().equals("")){
            List<SuperHero> listA = new ArrayList<>();

            List<SuperHero> listB = new ArrayList<>();
            String str1 = storeHuman.getText();
            String str2 = storeMutant.getText();
            List<SuperHero> lists =  superHeroList ;
            for (int i = 0; i < lists.size(); i++) {
                if(lists.get(i).getRace().equals(str1)){
                    listA.add(lists.get(i));
                }
                if(lists.get(i).getRace().equals(str2)){
                    listB.add(lists.get(i));
                }
            }
            FightResult fightResult = battleRoyale(listA,listB);
            String rat1= df.format((float)fightResult.getLoss()/fightResult.getWin());
            String rat2 = df.format((float)fightResult.getWin()/fightResult.getLoss());
            System.out.println(rat1);
            System.out.println(rat2);
            if(fightResult.getLoss()>fightResult.getWin()){
                winner.setText(storeHuman.getText());
                loser.setText(storeMutant.getText());
                win1.setText(fightResult.getLoss()+"");
                loss1.setText(fightResult.getWin()+"");
                win2.setText(fightResult.getWin()+"");
                loss2.setText(fightResult.getLoss()+"");

                ratio1.setText(Double.parseDouble(rat1)*100+"%");
                ratio2.setText(Double.parseDouble(rat2)*100+"%");
            }else {
                winner.setText(storeMutant.getText());
                loser.setText(storeHuman.getText());

                win1.setText(fightResult.getWin()+"");
                loss1.setText(fightResult.getLoss()+"");
                win2.setText(fightResult.getLoss()+"");
                loss2.setText(fightResult.getWin()+"");

                ratio1.setText(Double.parseDouble(rat2)*100+"%");
                ratio2.setText(Double.parseDouble(rat1)*100+"%");
            }

        }

    }



    private void LoadData(){
        superList.removeAll(list);
        superList.add("Superhero1.csv");
        superList.add("Superhero2.csv");
        superList.add("Superhero3.csv");
        superList.add("Superhero4.csv");
        superList.add("Superhero5.csv");
        strength.getItems().addAll(superList);
        race.getItems().addAll(superList);
        raceTh.getItems().addAll(superList);

        strength.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                System.out.println(newValue.toString());
                try {
                    List<SuperHero> list = readDataFile("data/"+newValue);

                    System.out.println(list);
                    List<Integer> intList = getStats(list);
                    stockMin.setText(String.valueOf(intList.get(0)));
                    stockMax.setText(String.valueOf(intList.get(1)));
                    stockAverage.setText(String.valueOf(intList.get(2)));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        raceTh.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                System.out.println(newValue.toString());
                try {
                    List<SuperHero> list = readDataFile("data/"+newValue);
                    System.out.println(storeSearch.getText());
                    stockArea.setText(getListThatContainsString(list,storeSearch.getText()));
//                  System.out.println(info);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        race.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {
            @Override
            public void changed(ObservableValue observable, Object oldValue, Object newValue) {
                System.out.println(newValue.toString());
                try {
                    superHeroList = readDataFile("data/"+newValue);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    /**
     *
     * @param fileName
     * @return
     * @throws IOException
     */
    public List<SuperHero>  readDataFile(String fileName) throws IOException {
        ArrayList<SuperHero> heroes = new ArrayList<>();
        File file = new File(fileName);
        Scanner fileReader = new Scanner(file);
        fileReader.nextLine(); //skip headers
        int fieldCount = 16;
        while(fileReader.hasNextLine()){
            String[] fields = fileReader.nextLine().split(",");

            if(fields.length != fieldCount){ //parsing error or problem with file
                System.out.println("expected 16 fields but counted " + fields.length);
                for(String str : fields)
                    System.out.println(str);
                throw new IOException();
            }

            SuperHero hero;

            if(MasterMind.meetsConditions(fields))
                hero = new MasterMind(fields);
            else
                hero = new SuperHero(fields);

            heroes.add(hero);
        }

        return heroes;
    }



    /**
     *
     * @param filename
     * @param simplified
     * @return
     * @throws IOException
     */
    public List<SuperHero>  readStrengthFile(String filename, boolean simplified) throws IOException {
        int simplifiedLinesToRead = 10; //if the simplified flag is true, then only read 10 lines.
        int minPopularVotesNeeded = -1, year = -1;
        ArrayList<SuperHero> superHeroList = new ArrayList<>();
        Scanner fileReader = new Scanner(new File(filename));
        String[] firstLine = fileReader.nextLine().split(",");
        int votes = simplified ? 2 : 1;

        year = Integer.parseInt(firstLine[0]);
        minPopularVotesNeeded = Integer.parseInt(firstLine[votes]);

        int linesRead = 1;
        while(fileReader.hasNextLine() && (!simplified || linesRead < simplifiedLinesToRead)){
            String[] fields = fileReader.nextLine().split(",");
            SuperHero superHero = new SuperHero(fields[0], Integer.parseInt(fields[2]), Integer.parseInt(fields[3]));
            superHeroList.add(superHero);
            linesRead++;
        }
        return superHeroList;
    }


    /**
     *
     * @param list
     * @return
     */
    public List<Integer>  getStats(List<SuperHero> list){
        int min = 0;
        int max = 0;
        int average = 0;
        for (int i = 0; i < list.size(); i++) {
             if(max <list.get(i).getStrength()){
                 max = list.get(i).getStrength();
             }
             if(i == 0){
                 min = list.get(i).getStrength();
                 if(min>list.get(i).getStrength()){
                     min = list.get(i).getStrength();
                 }
             }
            average += list.get(i).getStrength();
        }
        List<Integer> intList = new ArrayList<>();
        intList.add(min);
        intList.add(max);
        intList.add(average/list.size());
        return intList;
    }

    /**
     *
     * @param list
     * @param text
     * @return
     */
    public String getListThatContainsString(List<SuperHero> list, String text){
        String str = "";
        if(text==null){
            for (int i = 0; i < list.size(); i++) {
                 str+=list.get(i).getName()+"\n";
            }
        }else {
            for (int i = 0; i < list.size(); i++) {

                if(list.get(i).getName().contains(text)){
                    str +=list.get(i).getName()+"\n";
                }
            }
        }
        return  str;
    }
    /**
     *
     * @param strList
     * @param text
     * @return
     */
    public String getListThatContainsString(String[] strList,String text){
        String str = "";
        if(text==null){
            for (int i = 0; i < strList.length; i++) {
                str+=strList[i]+"\n";
            }
        }else {
            for (int i = 0; i < strList.length; i++) {
                if(strList[i]!=null&&strList[i].contains(text)){
                    str +=strList[i]+"\n";
                }
            }
        }
        return  str;
    }

    public FightResult battleRoyale(List<SuperHero> listA,List<SuperHero> listB){
        int sizeA = listA.size();
        int sizeB =listB.size();
        FightResult fightResult = new FightResult();
        int loss = 0;
        int win =0;
        String ratio = "";
        if(sizeB>sizeA){
            for (int i = 0; i < listA.size(); i++) {
                int a =  superHero.getMaxAttribute(listA.get(i));
                int b =  superHero.getMaxAttribute(listB.get(i));
                if(a<b){
                    win ++;
                }else if(a>b){
                    loss++;
                }
            }
            win += (sizeB - sizeA);
        }else {
            for (int i = 0; i < listB.size(); i++) {
                int a =  superHero.getMaxAttribute(listA.get(i));
                int b =  superHero.getMaxAttribute(listB.get(i));
                if(a<b){
                    win ++;
                }else if(a>b){
                    loss++;
                }
            }
            loss += (sizeA -sizeB);
        }
        fightResult.setWin(win);
        fightResult.setLoss(loss);
        //fightResult.setRatio();

        return  fightResult;
    }

    public static List<SuperHero> getSuperHeroList() {
        return superHeroList;
    }

    public static void setSuperHeroList(List<SuperHero> superHeroList) {
        Controller.superHeroList = superHeroList;
    }
}
