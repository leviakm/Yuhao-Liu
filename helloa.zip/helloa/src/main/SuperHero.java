package main;


import java.util.ArrayList;
import java.util.Arrays;


public class SuperHero {

    private String name;
    private int intelligence;
    private int strength;
    private int speed;
    private int durability;
    private int power;
    private int combat;
    private String fullName;
    private String alignment;
    private String gender;
    private String race;
    private String height;
    private String weight;
    private String eyeColor;
    private String hairColor;
    private String occupation;
//    @Override
//    public String toString() {
//        return "Person{" +
//                "name='" + name + '\'' +
//                ", electoralVotes=" + electoralVotes +
//                ", popularVotes=" + popularVotes +
//                '}';
//    }
//
//    public SuperHero(String name, int electoralVotes, int popularVotes) {
//        this.name = name;
//        this.electoralVotes = electoralVotes;
//        this.popularVotes = popularVotes;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public int getElectoralVotes() {
//        return electoralVotes;
//    }
//
//    public void setElectoralVotes(int electoralVotes) {
//        this.electoralVotes = electoralVotes;
//    }
//
//    public int getPopularVotes() {
//        return popularVotes;
//    }
//
//    public void setPopularVotes(int popularVotes) {
//        this.popularVotes = popularVotes;
//    }

    public SuperHero(String name, int intelligence, int strength, int speed, int durability, int power, int combat, String fullName, String alignment, String gender, String race, String height, String weight, String eyeColor, String hairColor, String occupation) {
        this.name = name;
        this.intelligence = intelligence;
        this.strength = strength;
        this.speed = speed;
        this.durability = durability;
        this.power = power;
        this.combat = combat;
        this.fullName = fullName;
        this.alignment = alignment;
        this.gender = gender;
        this.race = race;
        this.height = height;
        this.weight = weight;
        this.eyeColor = eyeColor;
        this.hairColor = hairColor;
        this.occupation = occupation;
    }
    public SuperHero(String name, int intelligence, int strength){
        this.name = name;
        this.intelligence = intelligence;
        this.strength = strength;
    }

    public SuperHero(String[] fields){
            this.name = fields[0];
            this.intelligence = Integer.parseInt(fields[1]);
            this.strength = Integer.parseInt(fields[2]);
            this.name = fields[0];
            this.intelligence = Integer.parseInt(fields[1]);
            this.strength = Integer.parseInt(fields[2]);
            this.speed = Integer.parseInt(fields[3]);
            this.durability = Integer.parseInt(fields[4]);
            this.power = Integer.parseInt(fields[5]);
            this.combat = Integer.parseInt(fields[6]);
            this.fullName = fields[7];
            this.alignment = fields[8];
            this.gender = fields[9];
            this.race = fields[10];
            this.height = fields[11];
            this.weight = fields[12];
            this.eyeColor = fields[13];
            this.hairColor = fields[14];
            this.occupation = fields[15];

    }

    public String getName() {
        return name;
    }

    public int getIntelligence() {
        return intelligence;
    }

    public int getStrength() {
        return strength;
    }

    public int getSpeed() {
        return speed;
    }

    public int getDurability() {
        return durability;
    }

    public int getPower() {
        return power;
    }

    public int getCombat() {
        return combat;
    }

    public String getFullName() {
        return fullName;
    }

    public String getAlignment() {
        return alignment;
    }

    public String getGender() {
        return gender;
    }

    public String getRace() {
        return race;
    }

    public String getHeight() {
        return height;
    }

    public String getWeight() {
        return weight;
    }

    public String getEyeColor() {
        return eyeColor;
    }

    public String getHairColor() {
        return hairColor;
    }

    public String getOccupation() {
        return occupation;
    }

    public int attack(SuperHero oHero){
        return this.combat;
    }

    public static boolean meetsConditions(String[] fields){
        return true;
    }


    public static int getMaxAttribute(SuperHero hero){
        //Figure out which attribute is the highest
        int[] str = {hero.getIntelligence(),hero.getStrength(),hero.getSpeed(),hero.getDurability(),hero.getPower(),hero.getCombat()};

        return Arrays.stream(str).max().getAsInt();
    }

}
